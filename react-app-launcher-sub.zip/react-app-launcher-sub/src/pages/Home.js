import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Home() {
  const [appId, setAppId] = useState("");
  const [customerId, setCustomerId] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate(`/dashboard?appId=${appId}&customerId=${customerId}`);
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h2>🚀 Launch App</h2>
      <form onSubmit={handleSubmit}>
        <label>
          App ID:
          <input
            type="text"
            value={appId}
            onChange={(e) => setAppId(e.target.value)}
            required
            style={{ display: "block", margin: "10px 0", padding: "5px" }}
          />
        </label>
        <label>
          Customer ID:
          <input
            type="text"
            value={customerId}
            onChange={(e) => setCustomerId(e.target.value)}
            required
            style={{ display: "block", margin: "10px 0", padding: "5px" }}
          />
        </label>
        <button type="submit" style={{ padding: "8px 16px" }}>Launch</button>
      </form>
    </div>
  );
}

export default Home;