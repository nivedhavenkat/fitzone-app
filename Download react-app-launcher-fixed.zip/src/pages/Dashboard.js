import { useSearchParams } from "react-router-dom";
import { useEffect } from "react";

function Dashboard() {
  const [params] = useSearchParams();
  const appId = params.get("appId");
  const customerId = params.get("customerId");

  useEffect(() => {
    // Step 1: Load the Chargebee Lifecycle Offers SDK
    const script = document.createElement("script");
    script.src = "https://app.retention.chargebee.com/assets/webpack/retention.js";
    script.async = true;

    // Step 2: Call Retention.init after the script is loaded
    script.onload = () => {
      if (window.Retention && appId && customerId) {
        console.log("Calling Retention.init...");
        window.Retention.init({
          appId: appId,
          customerId: customerId
        });

        // Optional: Show the offer automatically
        // window.Retention.showOffer();
      }
    };

    // Add the script to the page
    document.body.appendChild(script);

    // Clean up when component is removed
    return () => {
      document.body.removeChild(script);
    };
  }, [appId, customerId]); // Re-run if appId/customerId change

  return (
    <div style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <h1>Welcome to FitZone</h1>
      <p>App ID: {appId}</p>
      <p>Customer ID: {customerId}</p>
      {/* UI content here */}
    </div>
  );
}

export default Dashboard;